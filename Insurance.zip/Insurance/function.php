<?php 
  /*
  Plugin Name: Insurance
  Description: IDS insurance 
  Author: IDS
  Version: 1.1
  */

  if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

  define('CARMAKE'   , 'car_make');
  define('CARMODEL'  , 'car_model');
  define('CARYEAR'   , 'car_year');
  define('INSURANCE' , 'insurance');

  class carInsurance{  

    public function __construct(){
      register_activation_hook( __FILE__,[$this,'fetchCarInfo'] );
    }

    public function fetchCarInfo(){
      global $wpdb;
      $prefix = $wpdb->prefix;
      $query = "
        SELECT 
          cModel.`name` as modelName,
          cMake.`name` as makeName,
          cMake. `image` as makeImage,
          cYear.`name` as generationName,
          cYear.`year_begin` as yearBegin,
          cYear.`year_end` as yearEnd
        FROM 
          `".$prefix.CARYEAR."` as cYear
        INNER JOIN `".$prefix.CARMODEL."` as cModel
          ON cModel.`id_car_model` = cYear.`id_car_model`
        INNER JOIN `".$prefix.CARMAKE."` as cMake
          ON cModel.`id_car_make` = cMake.`id_car_make`
      ";

      //SELECT cModel.`name` as modelName, cMake.`name` as makeName, cMake. `image` as makeImage, cYear.`name` as generationName, cYear.`year_begin` as yearBegin, cYear.`year_end` as yearEnd FROM `wp_car_year` as cYear INNER JOIN `car_model` as cModel ON cModel.`id_car_model` = cYear.`id_car_model` INNER JOIN `car_make` as cMake ON cModel.`id_car_make` = cMake.`id_car_make`


      //$fetch = $wpdb->query($query);
      
      $fetchAll = $wpdb->get_results( $wpdb->prepare($query, "%s"),ARRAY_A );


      $response = [];

      // debug($response);
      
      
      $uniqueYears = [];
      $uniqueMake  = [];
      $uniqueModel = [];
      $uniqueImage = [];
      
      foreach( $fetchAll as $singleRow ){
      
        $yearBegin = intval( $singleRow['yearBegin'] );
        $yearEnd = intval( $singleRow['yearEnd'] );
        $generationName = $singleRow['generationName'];
        $makeName = $singleRow['makeName'];
        $modelName = $singleRow['modelName'];
        $makeImage = $singleRow['makeImage'];
      
        
      
        if( empty($generationName) || empty($makeName) || empty($modelName) ){
          debug("One of the generationName, makeName or modelName is empty");
          continue;
        }
      
        # In case both start and end year are zero
        if( empty($yearBegin) && empty($yearEnd) ){
          continue;
        }
      
        # In case yearBegin is empty
        if( empty( $yearBegin ) ){
          $yearBegin = $yearEnd;
        }
      
        # In case yearEnd is empty
        if( empty( $yearEnd ) ){
          $yearBegin = $yearEnd;
        }
      
        if( $yearBegin > $yearEnd || empty($yearBegin) ){
          # debug("This is error case and shouln't happen");
          continue;
        }
      
      
        for( $year = $yearBegin; $year <= $yearEnd; $year++){
        
          if( empty($response[$year]) ){
            $response[$year] = [];
            if( !in_array($year, $uniqueYears)){
              $uniqueYears[] = $year;
            }
          }
      
          if( empty($response[$year][$makeName]) ){
            $response[$year][$makeName] = [];
            if( !in_array($makeName, array_column($uniqueMake, 'name')) ){
              $uniqueMake[] = [ 
                'name'=>$makeName,
                'makeImage'=>$makeImage,
              ];
      
            }      
          }    
      
          // if( in_array( $generationName, $response[$year][$makeName][$modelName] )){
          if( in_array( $modelName, $response[$year][$makeName] )){
            # debug("This is not possible and shouldn't be the case, multiple generationName row");
            continue;
          }
      
          $response[$year][$makeName][] = $modelName;
      
        }
      }
      
      sort( $uniqueYears );
      sort( $uniqueMake );
      sort( $uniqueModel );

      //$this->debug($response);
      return $response;
      //wp_die();

    }

    private function debug($args){
      echo "<pre>";
        print_r($args);
      echo "</pre>";
    }

  }

  new carInsurance();

?>